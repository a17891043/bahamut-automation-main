export const LINK = {
    DISCORD: "https://discord.gg/Ff8q2SGut2",
    GITLAB: "https://gitlab.com/JacobLinCool/bahamut-automation",
} as const;

export const BRWOSER_TYPES = ["chromium", "firefox", "webkit"] as const;

export const VERBOSE = process.env.VERBOSE ? true : false;
