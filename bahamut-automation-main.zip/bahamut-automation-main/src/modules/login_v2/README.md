# Login V2

- Module Name: `login_v2`

## 參數

必要參數
- `username` - 帳號
- `password` - 密碼

可選參數
- `twofa` - 兩步驗驗證碼
- `login_max_attempts` - 最多登入失敗次數

### 使用方法

請將 `login` 換成 `login_v2` 即可
