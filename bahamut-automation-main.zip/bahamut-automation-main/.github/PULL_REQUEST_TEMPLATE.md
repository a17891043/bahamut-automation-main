### 檢查表

* [ ] 你有跑過 `npm run format` 了嗎？
* [ ] 你有跑過 `npm run build` 了嗎？
* [ ] 你有在 `local` 成功執行 `binary` 和 `cli` (`npm start`) 了嗎？
