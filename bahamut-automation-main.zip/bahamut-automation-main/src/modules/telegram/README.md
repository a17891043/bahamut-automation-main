# Telegram Module

1. 需使用 Bahamut Automation v0.6.3+
2. 在 `.github/workflows/automation.yml` 中 `modules` 參數中加上 `telegram` ，記得要確認是否每個模組都有用 `,` 隔開
3. 在 Telegram 中與[此機器人](http://t.me/automia_bot)開始對話，獲取通道 ID
4. 在 Secrets `parameters` 參數中加上 `channel`，其值為通道 ID

## 附註

不要亂搞我的機器人！不要傳一堆無意義的訊息！
